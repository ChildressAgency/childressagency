# grid-accordion
A pure jQuery plugin that allows you to create a grid accordion.
